#!/usr/bin/env python3
# main.py - Cisco Network Automation Entry Point

from utils.precheck import check_and_install_modules
from menu import show_menu

def main():
    """Ponto de entrada principal para automação de dispositivos Cisco"""
    check_and_install_modules()
    show_menu()

if __name__ == "__main__":
    main()

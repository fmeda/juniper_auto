from .ssh_connection import connect_ssh

def apply_ssh_hardening():
    hostname = input("IP do dispositivo Cisco: ")
    username = input("Usuário: ")
    client = connect_ssh(hostname, username)
    if not client:
        return
    commands = [
        "configure terminal",
        "ip domain-name secure.local",
        "crypto key generate rsa modulus 2048",
        "ip ssh version 2",
        "ip ssh timeout 60",
        "ip ssh authentication-retries 2",
        "line vty 0 4",
        "transport input ssh",
        "login local",
        "exit",
        "end",
        "write memory"
    ]
    shell = client.invoke_shell()
    for cmd in commands:
        shell.send(cmd + "\n")
    print("Hardening SSH aplicado.")
    client.close()


from .ssh_connection import connect_ssh

def apply_user_hardening():
    hostname = input("IP do dispositivo Cisco: ")
    username = input("Usuário: ")
    client = connect_ssh(hostname, username)
    if not client:
        return
    commands = [
        "configure terminal",
        "no username cisco",
        "username admin privilege 15 secret ForteSenha123!",
        "exit",
        "end",
        "write memory"
    ]
    shell = client.invoke_shell()
    for cmd in commands:
        shell.send(cmd + "\n")
    print("Hardening de usuários aplicado.")
    client.close()

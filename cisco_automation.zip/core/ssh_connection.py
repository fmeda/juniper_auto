import paramiko
from getpass import getpass

def connect_ssh(hostname, username):
    password = getpass("Digite a senha: ")
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname, username=username, password=password, look_for_keys=False)
        return client
    except paramiko.ssh_exception.AuthenticationException:
        print("Erro de autenticação. Verifique o usuário/senha.")
        return None

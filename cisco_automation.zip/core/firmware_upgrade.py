from .ssh_connection import connect_ssh

def upgrade_firmware():
    hostname = input("IP do dispositivo Cisco: ")
    username = input("Usuário: ")
    client = connect_ssh(hostname, username)
    if not client:
        return
    stdin, stdout, stderr = client.exec_command("show version")
    print(stdout.read().decode())
    print(">> Lógica de upgrade real deve ser aplicada aqui (upload e boot do firmware)")
    client.close()

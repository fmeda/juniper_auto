import importlib.util
import subprocess
import sys

REQUIRED_MODULES = ["paramiko"]

def check_and_install_modules():
    for module in REQUIRED_MODULES:
        if importlib.util.find_spec(module) is None:
            print(f"Instalando módulo necessário: {module}")
            subprocess.check_call([sys.executable, "-m", "pip", "install", module])

from core.firmware_upgrade import upgrade_firmware
from core.ssh_hardening import apply_ssh_hardening
from core.user_hardening import apply_user_hardening

def show_menu():
    while True:
        print("\n=== CISCO NETWORK AUTOMATION ===")
        print("1. Atualizar Firmware")
        print("2. Aplicar Hardening SSH")
        print("3. Aplicar Hardening de Usuários")
        print("0. Sair")
        choice = input("Escolha uma opção: ")
        if choice == "1":
            upgrade_firmware()
        elif choice == "2":
            apply_ssh_hardening()
        elif choice == "3":
            apply_user_hardening()
        elif choice == "0":
            print("Encerrando...")
            break
        else:
            print("Opção inválida. Tente novamente.")

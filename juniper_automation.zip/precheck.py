import importlib
import subprocess
import sys

def run_precheck():
    print("[*] Verificando dependências...")

    required_modules = ["paramiko", "getpass"]
    for mod in required_modules:
        try:
            importlib.import_module(mod)
        except ImportError:
            print(f"[+] Instalando módulo ausente: {mod}")
            subprocess.check_call([sys.executable, "-m", "pip", "install", mod])

from core import firmware_upgrade, ssh_hardening, user_hardening

def show_menu():
    while True:
        print("\n=== JUNIPER NETWORK AUTOMATION ===")
        print("1. Atualizar Firmware")
        print("2. Aplicar Hardening SSH")
        print("3. Aplicar Hardening Usuários")
        print("0. Sair")

        choice = input("Escolha uma opção: ")

        if choice == "1":
            firmware_upgrade.upgrade_firmware()
        elif choice == "2":
            ssh_hardening.apply_ssh_hardening()
        elif choice == "3":
            user_hardening.apply_user_hardening()
        elif choice == "0":
            print("Encerrando...")
            break
        else:
            print("Opção inválida. Tente novamente.")

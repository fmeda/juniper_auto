import sys
import os

# Ajusta o path para imports relativos
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

from precheck import run_precheck
from menu import show_menu

def main():
    run_precheck()
    show_menu()

if __name__ == "__main__":
    main()

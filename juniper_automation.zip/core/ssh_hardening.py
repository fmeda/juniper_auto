from core.ssh_connection import create_ssh_client, execute_command, close_ssh_client
from utils.logger import log_action

def apply_ssh_hardening():
    hostname = input("Informe o IP/hostname do dispositivo Juniper: ")
    log_action("Iniciando hardening SSH")

    try:
        client = create_ssh_client(hostname)

        # Comandos de exemplo (ajustar conforme política)
        cmds = [
            "set system services ssh protocol-version v2",
            "set system services ssh root-login deny",
            "set system services ssh connection-limit 10",
            "set system services ssh rate-limit 5"
        ]

        for cmd in cmds:
            output, error = execute_command(client, cmd)
            if error:
                print(f"Erro ao executar {cmd}: {error}")

        print("Hardening SSH aplicado com sucesso.")
        close_ssh_client(client)
        log_action("Hardening SSH concluído")
    except Exception as e:
        log_action(f"Erro no hardening SSH: {e}")
        print(f"Falha: {e}")

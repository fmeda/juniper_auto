from core.ssh_connection import create_ssh_client, execute_command, close_ssh_client
from utils.logger import log_action

def apply_user_hardening():
    hostname = input("Informe o IP/hostname do dispositivo Juniper: ")
    log_action("Iniciando hardening de usuários")

    try:
        client = create_ssh_client(hostname)

        cmds = [
            "delete system login user testuser",  # Exemplo: remover usuário inativo
            "set system login password-expiration 90",  # Política senha expira em 90 dias
            "set system login retry-options tries-before-disconnect 3"
        ]

        for cmd in cmds:
            output, error = execute_command(client, cmd)
            if error:
                print(f"Erro ao executar {cmd}: {error}")

        print("Hardening de usuários aplicado com sucesso.")
        close_ssh_client(client)
        log_action("Hardening de usuários concluído")
    except Exception as e:
        log_action(f"Erro no hardening de usuários: {e}")
        print(f"Falha: {e}")

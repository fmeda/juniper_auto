from core.ssh_connection import create_ssh_client, execute_command, close_ssh_client
from utils.logger import log_action

def upgrade_firmware():
    hostname = input("Informe o IP/hostname do dispositivo Juniper: ")
    log_action("Iniciando atualização de firmware")

    try:
        client = create_ssh_client(hostname)

        cmd_ver = "show version"
        output, error = execute_command(client, cmd_ver)
        if error:
            print("Erro ao obter versão do firmware.")
        else:
            print(f"Versão atual do firmware:\n{output}")

        print("[+] Para atualizar o firmware, envie o arquivo e execute o comando adequado.")
        print("     ATENÇÃO: Customize essa parte para seu ambiente!")

        confirm = input("Deseja reiniciar o dispositivo após a atualização? (s/n): ")
        if confirm.lower() == 's':
            execute_command(client, "request system reboot")
            print("Dispositivo será reiniciado.")

        close_ssh_client(client)
        log_action("Firmware atualizado com sucesso")
    except Exception as e:
        log_action(f"Erro durante atualização de firmware: {e}")
        print(f"Falha: {e}")

import paramiko
import logging
from utils.secrets_manager import get_device_credentials

def create_ssh_client(hostname, port=22, timeout=10):
    username, password = get_device_credentials()

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        client.connect(hostname=hostname, port=port, username=username, password=password, timeout=timeout)
        logging.info(f"Conectado a {hostname} via SSH.")
        return client
    except Exception as e:
        logging.error(f"Falha na conexão SSH: {e}")
        raise

def execute_command(client, command):
    stdin, stdout, stderr = client.exec_command(command)
    output = stdout.read().decode()
    error = stderr.read().decode()
    if error:
        logging.error(f"Erro ao executar '{command}': {error}")
    return output, error

def close_ssh_client(client):
    client.close()
    logging.info("Conexão SSH encerrada.")

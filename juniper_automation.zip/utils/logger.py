from datetime import datetime

def log_action(message):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("automation.log", "a") as log_file:
        log_file.write(f"[{now}] {message}\n")

import getpass

def get_device_credentials():
    username = input("Usuário SSH: ")
    password = getpass.getpass("Senha SSH: ")
    return username, password

